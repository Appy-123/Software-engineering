
package NotePad;
import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.event.*;
import java.io.File;
import java.io.PrintWriter;
import java.util.Scanner;
import java.applet.Applet;
import java.sql.*;

import javax.swing.*;

public class Notepad extends JFrame {

	private static final long serialVersionUID = 1L;
	static int active =0;
	static int fsize=17;
	JFrame frame;
	JMenuBar menuBar;
	JMenu file;
	JMenu edit;
	JMenuItem open, newFile,save, exit;
	JMenuItem paste, selectAll, cut, copy,fontfamily, fontstyle, fontsize, status; 
        Font font1;
	JList familylist, stylelist, sizelist;
	JMenu format;
	JMenu view;
	JFileChooser fileChooser;
	JTextArea textArea;
	Clipboard clip ;
	String familyvalue[]={"Agency FB","Antiqua","Architect","Arial","Calibri","Algerian","Courier","Cursive","Impact","Serif"};
	String sizevalue[]={"5","10","15","20","25","30","35","40","45","50","55","60","65","70"};
	int [] stylevalue={ Font.PLAIN, Font.BOLD, Font.ITALIC };
	String [] stylevalues={ "PLAIN", "BOLD", "ITALIC" };
	String ffamily, fsizestr, fstylestr;
	int fstyle;
	int cl;
	int linecount;
	String tle ;
	String topicstitle = "";
	JScrollPane sp;
	JPanel bottom;
	JLabel details;
	
	Notepad() {
		frame = new JFrame("Notepad Application");
		file = new JMenu("File");
		edit = new JMenu("Edit");
		font1=new Font("Arial",Font.PLAIN,17);
		newFile = new JMenuItem("New");
		open = new JMenuItem("Open");		
		save = new JMenuItem("Save");
		exit = new JMenuItem("Exit");
		//undo = new  JMenuItem("Undo                 Ctrl+Z");
		paste = new JMenuItem("Paste                Ctrl+V");
		selectAll = new JMenuItem("Select All       Ctrl+A ");
                cut=new JMenuItem("Cut       Ctrl+X");
                copy=new JMenuItem("Copy        Ctrl+C");
		textArea = new JTextArea();
		fileChooser = new JFileChooser();
		menuBar = new JMenuBar();
		format = new JMenu("Format");
		view = new JMenu("View");

		bottom = new JPanel();
		details = new JLabel();
		bottom.add(details);
		fontfamily = new JMenuItem("Set Font Family");
		fontstyle = new JMenuItem("Set Font Style");
		fontsize = new JMenuItem("Set Font Size");
		status = new JMenuItem("Status");
		frame.setLayout(new BorderLayout());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		familylist = new JList(familyvalue);
		stylelist = new JList(stylevalues);
		sizelist = new JList(sizevalue);


		familylist.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		sizelist.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		stylelist.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);




        frame.add(textArea);
		file.add(open);
		file.add(newFile);
		file.add(save);
		file.add(exit);
		//edit.add(undo);
                edit.add(cut);
                edit.add(copy);
		edit.add(paste);
		edit.add(selectAll);
		menuBar.add(file);
		menuBar.add(edit);
		menuBar.add(format);
		menuBar.add(view);
		format.add(fontfamily);
		format.add(fontstyle);
		format.add(fontsize);

		view.add(status);
		frame.setJMenuBar(menuBar);
		
		OpenListener openL = new OpenListener();
		NewListener NewL = new NewListener();
		SaveListener saveL = new SaveListener();
		ExitListener exitL = new ExitListener();
                CutListener cutL=new CutListener();
                CopyListener copyL= new CopyListener();
                SelectAllListener seL=new SelectAllListener();
                StatusListener statusL= new StatusListener();
		open.addActionListener(openL);
		newFile.addActionListener(NewL);
		save.addActionListener(saveL);
		exit.addActionListener(exitL);
		fontsizeListener fontsizeL= new fontsizeListener();
		fontstyleListener fontstyleL= new fontstyleListener();
		fontfamilyListener fontfamilyL= new fontfamilyListener();
		fontsize.addActionListener(fontsizeL);
		fontstyle.addActionListener(fontstyleL);
		fontfamily.addActionListener(fontfamilyL);
                status.addActionListener(statusL);
		//UndoListener UndoL = new UndoListener();
		PasteListener pasteL = new PasteListener();
		//EditListener EditL = new EditListener();
		//SelectListener SelectL = new SelectListener();
		//undo.addActionListener(UndoL);
		paste.addActionListener(pasteL);
                cut.addActionListener(cutL);
                copy.addActionListener(copyL);
		selectAll.addActionListener(seL);
		frame.setSize(800, 600);
		frame.setVisible(true);
                frame.add(bottom, BorderLayout.SOUTH);
	}
	
	class OpenListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			if (JFileChooser.APPROVE_OPTION == fileChooser.showOpenDialog(frame)) {
				File file = fileChooser.getSelectedFile();
				textArea.setText("");
				Scanner in = null;
				try {
					in = new Scanner(file);
					while(in.hasNext()) {
						String line = in.nextLine();
						textArea.append(line+"\n");
					}
				} catch (Exception ex) {
					ex.printStackTrace();
				} finally {
					in.close();
				}
			}
		}
	}
	
	class SaveListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			if (JFileChooser.APPROVE_OPTION == fileChooser.showSaveDialog(frame)) {
				File file = fileChooser.getSelectedFile();
				PrintWriter out = null;
				try {
					out = new PrintWriter(file);
					String output = textArea.getText();
					System.out.println(output);
					out.println(output);
				} catch (Exception ex) {
					ex.printStackTrace();
				} finally {
					try {
						out.flush();
						} catch(Exception ex1) 
						{
							
						}
					try {
						out.close();
						} catch(Exception ex1) {
							
						}
				}
			}
		}
	}
	
	class NewListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			
			//frame.add(newFile);
                        textArea.setText("");
			//textArea.(newFile);
			
			
			
		}
	}
	class ExitListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			System.exit(0);
		}
	}
	class CutListener implements ActionListener {
			public void actionPerformed(ActionEvent e) {
			
	             textArea.cut();
	         }
	        
			
		
	}
	
 class fontfamilyListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {         
			JOptionPane.showConfirmDialog(null, familylist, "Choose Font Family", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
		ffamily=String.valueOf(familylist.getSelectedValue());
		font1=new Font(ffamily,fstyle,fsize);
		textArea.setFont(font1);
		}
         }	
 class fontstyleListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {         
			JOptionPane.showConfirmDialog(null, stylelist, "Choose Font Style", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
		fstyle=stylevalue[stylelist.getSelectedIndex()];
		font1=new Font(ffamily,fstyle,fsize);
		textArea.setFont(font1);
		}
         }
class fontsizeListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {         
			JOptionPane.showConfirmDialog(null, sizelist, "Choose Font Size", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
		fsizestr=String.valueOf(sizelist.getSelectedValue());
		fsize =Integer.parseInt(fsizestr);
		font1=new Font(ffamily,fstyle,fsize);
		textArea.setFont(font1);
		}
         }
	
	

			  
	 class PasteListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {         
			textArea.paste();
		}
         }
	
        class CopyListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			  textArea.copy();
	         
			
		}
	}
        class SelectAllListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			  textArea.selectAll();
	         
			
		}
	}
	class StatusListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			
			cl= textArea.getText().length();
	linecount = textArea.getLineCount();
	details.setText("Length: "+cl+" Line: "+linecount);
		
		
	         
			
		}
	}
 public void keyTyped(KeyEvent ke){
	cl= textArea.getText().length();
	linecount = textArea.getLineCount();
	details.setText("Length: "+cl+" Line: "+linecount);
}
	
	public static void main(String args[]) {
		Notepad n = new Notepad();
	}
}
